<?php $__env->startSection('title', 'Records overview'); ?>
<?php $__env->startSection('inhoud'); ?>
    <div class="row">
        <div class="col-md-9">
            <div class="row">
                <br/>
                <h1>test</h1>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <div class="caption">
                                <h4>
                                    <p><a href="#"><?php echo e($item->sord); ?></a></p>
                                </h4><br>
                                <h4 class="pull-right"><?php echo e($item->devicesn); ?></h4>
                                <div class="topbar"><p><?php echo e($item->complaint); ?></p></div>
                            </div>

                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="row">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Soufiane\Desktop\School_2018-2019\SOA_CloudComputing\Project\API-Services-Soa\UserInterface_(Laravel)\blog\resources\views/records/index.blade.php ENDPATH**/ ?>