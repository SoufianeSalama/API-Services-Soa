<html>
<head>
    <base href="<?php echo e(URL::asset('/')); ?>" target="_top">
    <meta charset="utf_8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Soufiane Salama">

    <title>TV-Repairs <?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <?php echo $__env->yieldContent('inhoud'); ?>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\Soufiane\Desktop\School_2018-2019\SOA_CloudComputing\Project\API-Services-Soa\UserInterface_(Laravel)\blog\resources\views/layouts/master.blade.php ENDPATH**/ ?>