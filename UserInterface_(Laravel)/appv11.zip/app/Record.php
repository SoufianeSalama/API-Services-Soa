<?php

namespace App;

//use Illuminate\Database\Eloquent\Model;

//class Record extends Model
class Record
{
    /*protected $fillable = [s
        'sord',
        'devicesn',
        'clientinfo',
        'complaint',
        'diagnose',
        'statuskey',
        'userid'
    ];*/

    public $sSord;
    public $sDevicesn;
    public $sBrand;
    public $sClientinfo;
    public $sClientaddress;
    public $sComplaint;
    public $sDiagnose;
    public $iStatuskey;
    public $sStatusDescription;
    public $iUserid;

}
